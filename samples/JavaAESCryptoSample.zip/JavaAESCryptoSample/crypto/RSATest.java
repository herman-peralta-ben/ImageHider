import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import javax.crypto.Cipher;

import java.io.File;
import java.io.DataInputStream;
import java.io.FileInputStream;

import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.security.KeyFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.lang.StringBuilder;

/**
 * javac RSATest.java
 * java RSATest <j/f> <data to encrypt> <privateKeyFile> <publicKeyFile>
 *
 * 
RSA can only encrypt data blocks that are shorter than the key length so what you normally do is

1) Generate a random key of the correct length required for AES (or similar).
2) Encrypt your data using AES or similar using that key
3) Encrypt the random key using your RSA key
Then you publish both the outputs from 2 and 3

To decrypt

1) Decrypt the AES key using your RSA key.
2) Decrypt the data using that AES key
 *
 * http://stackoverflow.com/questions/31359694/asymmetric-encryption-discrepancy-android-vs-java
 * http://www.programcreek.com/java-api-examples/java.security.KeyPairGenerator
 * http://codeartisan.blogspot.mx/2009/05/public-key-cryptography-in-java.html
 * http://stackoverflow.com/questions/1199058/how-to-use-rsa-to-encrypt-files-huge-data-in-c-sharp
 
 java RSATest j ../../file.txt

 */
public class RSATest {

    private static final String RSA_ECB_PKCS1_PADDING = "RSA/ECB/PKCS1Padding";

	private static final String JAVA_KEYS = "j";
	private static final String FILE_KEYS = "f";
	
    public static void main(String[] args) {		
		if(args.length < 2) { 
			System.out.println("Argumento invalido: java RSATest <op> <textfile> <privateKeyfile> <publicKeyfile>\n\top: j - java keygen\n\t    f - file keys");
			return;
		}
		
		String data =	;
		try {
			data = readFile(args[1]);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		PrivateKey privateKey = null;
		PublicKey publicKey = null;
		
		switch(args[0]) {
			case JAVA_KEYS:
				KeyPair kp = generateRSAKeyPair();

				privateKey = kp.getPrivate();
				publicKey = kp.getPublic();				
				break;
				
			case FILE_KEYS:
				try {
					Keys keys = readKeys(args[2], args[3]);
					
					privateKey = keys.privateKey;
					publicKey = keys.publicKey;	
				} catch(Exception e) {
					e.printStackTrace();
				}
				
				break;
		}
		
		prueba(data, privateKey, publicKey);
    }
	
	public static void prueba(String data, final PrivateKey privateKey, final PublicKey publicKey) {	
        byte[] encryptedValue = encryptRSA(publicKey, data.getBytes());
        byte[] decrytpedValue = decryptRSA(privateKey, encryptedValue);

        String decryptedData = new String(decrytpedValue);
		
		System.out.println("original  data:\n" + data);
		System.out.println("encrypted data:\n" + new String(encryptedValue));
        System.out.println("decrypted data:\n" + decryptedData);
	}

	/**
	 * 1) generateRSAKeyPair - This generates public private key pair. You will have 
	 *    to store public key on the app and private key on your server.
	 */ 
    public static KeyPair generateRSAKeyPair() {
        KeyPairGenerator keyGen;
        try {
            keyGen = KeyPairGenerator.getInstance("RSA");
            SecureRandom rnd = new SecureRandom();
            keyGen.initialize(2048, rnd); //SecureRandom.getInstance("SHA1PRNG", "SUN");
            KeyPair keyPair = keyGen.genKeyPair();
            return keyPair;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

	/**
	 * 2) encryptRSA - This method encrypts the given data using public key. 
	 *    It returns byte array that represents encrypted value. If you need, you can 
     *    do base 64 encoding of this value so that you can use it in JSON
	 */
    public static byte[] encryptRSA(Key key, byte[] data) {
        byte[] cipherText = null;
        try {
            final Cipher cipher = Cipher.getInstance(RSA_ECB_PKCS1_PADDING);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            cipherText = cipher.doFinal(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cipherText;
    }

	/**
	 * 3) decryptRSA - This decrypts the encrypted value using private key. Make sure 
	 *    that you pass raw encrypted value to this method, and not a base 64 encoded 
	 *    value.
	 */
    public static byte[] decryptRSA(Key key, byte[] data) {
        byte[] decryptedText = null;
        try {
            final Cipher cipher = Cipher.getInstance(RSA_ECB_PKCS1_PADDING);
            cipher.init(Cipher.DECRYPT_MODE, key);
            decryptedText = cipher.doFinal(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return decryptedText;
    }
	
	public static class Keys {
		PrivateKey privateKey;
		PublicKey publicKey;
	}
	
	/**
	 * # generate a 2048-bit RSA private key
	 * $ openssl genrsa -out private_key.pem 2048
	 *
	 * # convert private Key to PKCS#8 format (so Java can read it)
	 * $ openssl pkcs8 -topk8 -inform PEM -outform DER -in private_key.pem -out private_key.der -nocrypt
	 *
	 * # output public key portion in DER format (so Java can read it)
	 * $ openssl rsa -in private_key.pem -pubout -outform DER -out public_key.der
	 * 
	 * http://codeartisan.blogspot.mx/2009/05/public-key-cryptography-in-java.html
	 */ 
	public static Keys readKeys(String privateKeyFilename, String publicKeyFilename) throws Exception {
		Keys keys = new Keys();		
		
		keys.privateKey = readPrivateKey(privateKeyFilename);
		keys.publicKey = readPublicKey(publicKeyFilename);
		
		return keys;
	}
	
	public static PrivateKey readPrivateKey(String filename) throws Exception {    
		File f = new File(filename);
		FileInputStream fis = new FileInputStream(f);
		DataInputStream dis = new DataInputStream(fis);
		
		byte[] keyBytes = new byte[(int)f.length()];
		dis.readFully(keyBytes);
		dis.close();

		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance("RSA");
		
		return kf.generatePrivate(spec);
	}
	
	public static PublicKey readPublicKey(String filename) throws Exception {
		File f = new File(filename);
		FileInputStream fis = new FileInputStream(f);
		DataInputStream dis = new DataInputStream(fis);
		
		byte[] keyBytes = new byte[(int)f.length()];
		dis.readFully(keyBytes);
		dis.close();

		X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance("RSA");

		return kf.generatePublic(spec);
	}
	
	public static String readFile (String filename) throws IOException {
		StringBuilder sBuilder = new StringBuilder();
		
		BufferedReader br = new BufferedReader(new FileReader(filename));	
		String sCurrentLine;
		while ((sCurrentLine = br.readLine()) != null) {
			sBuilder.append(sCurrentLine);
		}
		
		return sBuilder.toString();
	}
}