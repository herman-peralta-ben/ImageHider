import java.io.File;

import java.awt.Desktop;

import crypto.*;

/**
 * javac -d bin/ Main.java
 * cd bin/
 * java Main t ../../original.jpg
 *
 * @author Herman Peralta
 */
public class Main {
	
	private static byte[] mPasswordBytes = {0, 0, 0, 0,
											0, 0, 0, 0,
											0, 0, 0, 0,
											0, 0, 0, 0};
	
	private final static String ACTION_ENCRYPT = "e";
	private final static String ACTION_DECRYPT = "d";
	private final static String ACTION_TEST    = "t";
	
	private final static AESManager.EncryptionActionListener defaultListener = new AESManager.EncryptionActionListener() {
		@Override
		public void onActionComplete() {
			System.out.println("Completo");		
		}
		
		@Override
		public void onProgress(int percent) {
			printProgressString(percent);
		}
	};
	
	public static void main(String[] args) {
		if(args.length != 2) {
			System.out.println("Argumento invalido: java Main <op> <filename>\n\top: e - encrypt\n\t    d - decrypt");
			return;
		}
		
		String filename = args[1];
		
		System.out.println("Encriptando '" + filename + "'");
		
		switch(args[0]) {
			case ACTION_ENCRYPT:
				AESManager.encrypt(mPasswordBytes, filename, filename + ".crypt", defaultListener);
				break;
				
			case ACTION_DECRYPT:
				AESManager.decrypt(mPasswordBytes, filename, filename + ".decrypt", defaultListener);				
				break;
				
			case ACTION_TEST:
				final String cryptFN = filename + ".crypt";
				final String decryptFN = cryptFN + ".decrypt.jpg";
				
				AESManager.encrypt(mPasswordBytes, filename, cryptFN, new AESManager.EncryptionActionListener() {
					@Override
					public void onActionComplete() {
						System.out.println("Encriptado correcto en " + cryptFN);
						
						AESManager.decrypt(mPasswordBytes, cryptFN, decryptFN, new AESManager.EncryptionActionListener() {
							@Override
							public void onActionComplete() {
								System.out.println("Desencriptado correcto en " + decryptFN);
								System.out.println("Abriendo archivo de pruebas...");
								try {
									//http://stackoverflow.com/questions/7024031/java-open-a-file-windows-mac
									Desktop d = Desktop.getDesktop();  
									d.open(new File(decryptFN));
								} catch (Exception ex) {
									ex.printStackTrace();
									
									System.out.println("No fue posible abrir el archivo");
								} 							
							}
							
							@Override
							public void onProgress(int percent) {
								printProgressString(percent);
							}
						});				
					}
					
					@Override
					public void onProgress(int percent) {
						printProgressString(percent);
					}
				});
			
				break;
		}
	}
	
	private static void printProgressString(int percent) {
		System.out.print(String.format("%3d%%\b\b\b\b", percent));
	}
}