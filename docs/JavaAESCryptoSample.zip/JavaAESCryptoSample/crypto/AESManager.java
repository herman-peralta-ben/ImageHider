package crypto;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;


public class AESManager {
	
	public static void encrypt (final byte[] key,
			final String filename,
			final String newFilename,			
			final EncryptionActionListener listener) {
        	
		Thread task = new Thread("Encrypt thread") {
			public void run() {
				System.out.println("AESManager.encrypt Encriptando imagen: " + Thread.currentThread().toString());
				
				boolean deleteSuccess = true;
				boolean outOfMem = false;
				boolean exception = false;
				
				try {
					File file = new File(filename);
					int length = (int)file.length();
					
					byte fileBytes[] = new byte[1024*100];
					
					InputStream is = new FileInputStream(filename);
					OutputStream os = new FileOutputStream(newFilename);	
					AESOutputStream aos = new AESOutputStream(os, key, length);
					
					int totalRead = 0;
					int partialRead = 0;
					while (true) {
						partialRead = is.read(fileBytes);
						if (partialRead == -1) {
							break;
						} else {
							totalRead += partialRead;
							aos.write(fileBytes, 0, partialRead);
							final int percentage = (totalRead * 100) / length;	
							
							if(listener != null) { listener.onProgress(percentage); }
						}
					}
					
					is.close();
					aos.close();
					os.close();
					
					//deleteSuccess = file.delete();
				    
				    if (listener != null)
				    	listener.onActionComplete();
			
				} catch (OutOfMemoryError e) {
					e.printStackTrace();
					outOfMem = true;
				} catch (Exception e) {
					e.printStackTrace();
					exception = true;
				} finally {					
					if (exception) {						
						System.out.println("There was an error during encryption.");						
					} else if (outOfMem) {
						System.out.println("The application ran out of memory.");
					} else if (!deleteSuccess) {
						System.out.println("The original file was not deleted, but the encrypted file was still saved. YOUR PICTURE IS STILL ACCESSIBLE IN UNENCRYPTED FORM.");							
					} else {
						System.out.println("File encrypted: " + newFilename);
					}
				}
			}
		};
		
		task.start();
	}
	
	public static void decrypt (final byte[] key,
			final String filename,
			final String newFilename,
			final EncryptionActionListener listener) {
		
		Thread task = new Thread("Decrypt thread") {
			public void run() {
				boolean deleteSuccess = true;
				boolean outOfMem = false;
				boolean exception = false;
				
				try {
					File file = new File(filename);
					int length = (int)file.length();
					
					byte fileBytes[] = new byte[1024*100];
					
					InputStream is = new FileInputStream(filename);
					OutputStream os = new FileOutputStream(newFilename);	
					AESInputStream ais = new AESInputStream(is, key);
					
					int totalRead = 0;
					int partialRead = 0;
					while (true) {
						partialRead = ais.read(fileBytes);
						if (partialRead == -1) {
							break;
						} else {
							totalRead += partialRead;
							os.write(fileBytes, 0, partialRead);
							final int percentage = (totalRead * 100) / length;
							
							if(listener != null) { listener.onProgress(percentage); }							
						}
					}
					
					ais.close();
					is.close();
					os.close();
					
					//deleteSuccess = file.delete();
					
				    if (listener != null)
				    	listener.onActionComplete();
				    				    
				} catch (OutOfMemoryError e) {
					e.printStackTrace();
					outOfMem = true;
				} catch (Exception e) {
					e.printStackTrace();
					exception = true;
				} finally {					
					if (exception) {
						System.out.println("There was an error during decryption.");
					} else if (outOfMem) {					
						System.out.println("The application ran out of memory.");
					} else if (!deleteSuccess) {					
						System.out.println("The encrypted file was not deleted, but the decrypted file was still saved.");
					}
				}
			}
		};
		
		task.start();
	}
	
	
	public interface EncryptionActionListener {
		public void onActionComplete();
		public void onProgress(int percent);
	}
}
